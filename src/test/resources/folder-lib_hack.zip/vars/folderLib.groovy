Integer printMe() {
	println("folder me")
}

void changeSystemMessage(String newValue) {
	jenkins.model.Jenkins.get().systemMessage = "folder: " + newValue;
}