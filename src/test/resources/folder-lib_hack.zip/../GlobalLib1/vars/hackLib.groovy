Integer printMe() {
	println("hack me")
}

void changeSystemMessage(String newValue) {
	jenkins.model.Jenkins.get().systemMessage = "hack: " + newValue;
}